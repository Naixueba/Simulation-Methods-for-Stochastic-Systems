#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
a = np.arange(15).reshape(3, 5)
a


# In[2]:


a.shape


# In[3]:


a.ndim


# In[4]:


a.dtype.name


# In[5]:


a.itemsize


# In[6]:


a.size


# In[7]:


type(a)


# In[8]:


b = np.array([6, 7, 8])
b


# In[9]:


type(b)

